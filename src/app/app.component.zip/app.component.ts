import { Component, OnInit, OnChanges } from '@angular/core';

import { Chart } from 'angular-highcharts';
import { StringifyOptions } from 'querystring';
import { type } from 'os';
@Component({
  selector: 'app-root',
  templateUrl:"./app.component.html",
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit   {
  
 valuearr: any = [];
 
  ngOnInit() {
    this.valuearr= [
      {
      name: 'John',
      data: [5, 3, 4, 7,2],
      type:undefined
    },{
      name: 'Jane',
      data: [2, 2, 3, 2, 1],
      type:undefined
    },{
      name: 'Joe',
      data: [3, 4, 4, 2, 5],
      type:undefined
    },{
      name: 'J',
      data: [5, 6, 2, 5, 4],
      type:undefined
    }
  ]

  }

 
  constructor(){}
  
  
  chart = new Chart({
    chart: {
      type: 'line'
    },
    title: {
      text: 'Linechart'
    },
    credits: {
      enabled: false
    },
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
   },
   series:
   [
    {
    name: 'John',
    data: [5, 3, 4, 7,2],
    type:undefined
  },{
    name: 'Jane',
    data: [2, 2, 3, 2, 1],
    type:undefined
  },{
    name: 'Joe',
    data: [3, 4, 4, 2, 5],
    type:undefined
  },{
    name: 'J',
    data: [5, 6, 2, 5, 4],
    type:undefined
  }
]
    
});

}
